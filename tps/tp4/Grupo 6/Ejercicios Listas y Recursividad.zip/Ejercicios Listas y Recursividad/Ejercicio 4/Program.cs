﻿using System;
using System.Collections.Generic;

namespace TorneoPatoÑato
{
    class Chico
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }
        public string DNI { get; set; }
    }

    class Program
    {
        static List<Chico> chicos = new List<Chico>();
        static int indiceActual = 0; // para simular circularidad

        static void Main(string[] args)
        {
            int opcion;
            do
            {
                Console.WriteLine("\n--- MENU TORNEO PATO ÑATO ---");
                Console.WriteLine("1. Mostrar listado");
                Console.WriteLine("2. Registrar chico");
                Console.WriteLine("3. Eliminar chico");
                Console.WriteLine("4. Actualizar chico");
                Console.WriteLine("5. Insertar después de alguien");
                Console.WriteLine("6. Avanzar circularmente");
                Console.WriteLine("0. Salir");
                Console.Write("Opción: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1: MostrarListado(); break;
                    case 2: RegistrarChico(); break;
                    case 3: EliminarChico(); break;
                    case 4: ActualizarChico(); break;
                    case 5: InsertarDespues(); break;
                    case 6: AvanzarCircular(); break;
                }

            } while (opcion != 0);
        }

        static void MostrarListado()
        {
            Console.WriteLine("\n--- LISTADO DE CHICOS ---");
            for (int i = 0; i < chicos.Count; i++)
            {
                Console.WriteLine($"{i}. {chicos[i].Nombre} {chicos[i].Apellido} - Edad: {chicos[i].Edad} - DNI: {chicos[i].DNI}");
            }
        }

        static void RegistrarChico()
        {
            Console.Write("Nombre: ");
            string nombre = Console.ReadLine();
            Console.Write("Apellido: ");
            string apellido = Console.ReadLine();
            Console.Write("Edad: ");
            int edad = int.Parse(Console.ReadLine());
            Console.Write("DNI: ");
            string dni = Console.ReadLine();

            chicos.Add(new Chico { Nombre = nombre, Apellido = apellido, Edad = edad, DNI = dni });
        }

        static void EliminarChico()
        {
            MostrarListado();
            Console.Write("Ingrese posición a eliminar: ");
            int pos = int.Parse(Console.ReadLine());
            if (pos >= 0 && pos < chicos.Count)
                chicos.RemoveAt(pos);
        }

        static void ActualizarChico()
        {
            MostrarListado();
            Console.Write("Ingrese posición a actualizar: ");
            int pos = int.Parse(Console.ReadLine());
            if (pos >= 0 && pos < chicos.Count)
            {
                Console.Write("Nuevo nombre: ");
                chicos[pos].Nombre = Console.ReadLine();
                Console.Write("Nuevo apellido: ");
                chicos[pos].Apellido = Console.ReadLine();
                Console.Write("Nueva edad: ");
                chicos[pos].Edad = int.Parse(Console.ReadLine());
                Console.Write("Nuevo DNI: ");
                chicos[pos].DNI = Console.ReadLine();
            }
        }

        static void InsertarDespues()
        {
            MostrarListado();
            Console.Write("Ingrese posición después de la cual insertar: ");
            int pos = int.Parse(Console.ReadLine());
            if (pos >= 0 && pos < chicos.Count)
            {
                Console.Write("Nombre: ");
                string nombre = Console.ReadLine();
                Console.Write("Apellido: ");
                string apellido = Console.ReadLine();
                Console.Write("Edad: ");
                int edad = int.Parse(Console.ReadLine());
                Console.Write("DNI: ");
                string dni = Console.ReadLine();

                chicos.Insert(pos + 1, new Chico { Nombre = nombre, Apellido = apellido, Edad = edad, DNI = dni });
            }
        }

        static void AvanzarCircular()
        {
            if (chicos.Count == 0)
            {
                Console.WriteLine("No hay chicos registrados.");
                return;
            }

            indiceActual = (indiceActual + 1) % chicos.Count;
            var chico = chicos[indiceActual];
            Console.WriteLine($"Turno de: {chico.Nombre} {chico.Apellido} - Edad: {chico.Edad} - DNI: {chico.DNI}");
        }
    }
}
