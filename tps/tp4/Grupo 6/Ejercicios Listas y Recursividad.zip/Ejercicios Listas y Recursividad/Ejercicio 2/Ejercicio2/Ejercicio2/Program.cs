﻿using System;

namespace RegistroAlumnosEstudiante
{
    class Program
    {
        static void Main(string[] args)
        {
            // Tamaño máximo de la lista
            int MAX = 100;

            // Arreglos para guardar la información
            string[] dnis = new string[MAX];
            string[] nombres = new string[MAX];
            string[] apellidos = new string[MAX];
            string[] fechasNac = new string[MAX];
            string[] direcciones = new string[MAX];
            string[] telefonos = new string[MAX];

            int cantidad = 0; // Cantidad actual de alumnos registrados
            char opcion;

            do
            {
                Console.Clear();
                Console.WriteLine("=== SISTEMA DE ALUMNOS ===");
                Console.WriteLine("a-Registrar un nuevo alumno");
                Console.WriteLine("b-Eliminar alumno");
                Console.WriteLine("c-Actualizar alumno");
                Console.WriteLine("d-Agregar despues del seleccionado");
                Console.WriteLine("e-Agregar antes del seleccionado");
                Console.WriteLine("f-Mostrar listado");
                Console.Write("Elija una opcion: ");

                opcion = Console.ReadKey().KeyChar;
                Console.WriteLine();

                switch (char.ToLower(opcion))
                {
                    case 'a': // Registrar al final
                        if (cantidad < MAX)
                        {
                            Console.WriteLine("\n--- NUEVO ALUMNO ---");
                            Console.Write("DNI: ");
                            dnis[cantidad] = Console.ReadLine();
                            Console.Write("Nombres: ");
                            nombres[cantidad] = Console.ReadLine();
                            Console.Write("Apellidos: ");
                            apellidos[cantidad] = Console.ReadLine();
                            Console.Write("Fecha Nacimiento (DD/MM/AAAA): ");
                            fechasNac[cantidad] = Console.ReadLine();
                            Console.Write("Direccion: ");
                            direcciones[cantidad] = Console.ReadLine();
                            Console.Write("Telefono: ");
                            telefonos[cantidad] = Console.ReadLine();

                            cantidad++;
                            Console.WriteLine("Alumno registrado con exito.");
                        }
                        else
                        {
                            Console.WriteLine("La lista esta llena.");
                        }
                        break;

                    case 'b': // Eliminar
                        Console.WriteLine("\n--- ELIMINAR ALUMNO ---");
                        Console.Write("Ingrese el DNI del alumno a eliminar: ");
                        string dniEliminar = Console.ReadLine();
                        int posEliminar = -1;

                        for (int i = 0; i < cantidad; i++)
                        {
                            if (dnis[i] == dniEliminar)
                            {
                                posEliminar = i;
                                break;
                            }
                        }

                        if (posEliminar != -1)
                        {
                            // Desplazar los elementos hacia la izquierda
                            for (int i = posEliminar; i < cantidad - 1; i++)
                            {
                                dnis[i] = dnis[i + 1];
                                nombres[i] = nombres[i + 1];
                                apellidos[i] = apellidos[i + 1];
                                fechasNac[i] = fechasNac[i + 1];
                                direcciones[i] = direcciones[i + 1];
                                telefonos[i] = telefonos[i + 1];
                            }
                            cantidad--;
                            Console.WriteLine("Alumno eliminado.");
                        }
                        else
                        {
                            Console.WriteLine("No se encontro el DNI.");
                        }
                        break;

                    case 'c': // Actualizar
                        Console.WriteLine("\n--- ACTUALIZAR ALUMNO ---");
                        Console.Write("Ingrese el DNI a modificar: ");
                        string dniMod = Console.ReadLine();
                        int posMod = -1;

                        for (int i = 0; i < cantidad; i++)
                        {
                            if (dnis[i] == dniMod)
                            {
                                posMod = i;
                                break;
                            }
                        }

                        if (posMod != -1)
                        {
                            Console.Write("Nuevo Nombre: ");
                            nombres[posMod] = Console.ReadLine();
                            Console.Write("Nuevo Apellido: ");
                            apellidos[posMod] = Console.ReadLine();
                            Console.Write("Nueva Fecha Nacimiento: ");
                            fechasNac[posMod] = Console.ReadLine();
                            Console.Write("Nueva Direccion: ");
                            direcciones[posMod] = Console.ReadLine();
                            Console.Write("Nuevo Telefono: ");
                            telefonos[posMod] = Console.ReadLine();

                            Console.WriteLine("Datos actualizados.");
                        }
                        else
                        {
                            Console.WriteLine("Alumno no encontrado.");
                        }
                        break;

                    case 'd': // Agregar después
                        if (cantidad >= MAX)
                        {
                            Console.WriteLine("Lista llena.");
                            break;
                        }

                        Console.Write("Ingrese DNI de referencia: ");
                        string dniRefD = Console.ReadLine();
                        int posRefD = -1;

                        for (int i = 0; i < cantidad; i++)
                        {
                            if (dnis[i] == dniRefD)
                            {
                                posRefD = i;
                                break;
                            }
                        }

                        if (posRefD != -1)
                        {
                            int posInsertar = posRefD + 1;

                            // Mover todo a la derecha para abrir espacio
                            for (int i = cantidad; i > posInsertar; i--)
                            {
                                dnis[i] = dnis[i - 1];
                                nombres[i] = nombres[i - 1];
                                apellidos[i] = apellidos[i - 1];
                                fechasNac[i] = fechasNac[i - 1];
                                direcciones[i] = direcciones[i - 1];
                                telefonos[i] = telefonos[i - 1];
                            }

                            // Pedir datos del nuevo
                            Console.Write("DNI: ");
                            dnis[posInsertar] = Console.ReadLine();
                            Console.Write("Nombres: ");
                            nombres[posInsertar] = Console.ReadLine();
                            Console.Write("Apellidos: ");
                            apellidos[posInsertar] = Console.ReadLine();
                            Console.Write("Fecha Nacimiento: ");
                            fechasNac[posInsertar] = Console.ReadLine();
                            Console.Write("Direccion: ");
                            direcciones[posInsertar] = Console.ReadLine();
                            Console.Write("Telefono: ");
                            telefonos[posInsertar] = Console.ReadLine();

                            cantidad++;
                            Console.WriteLine("Alumno insertado despues del seleccionado.");
                        }
                        else
                        {
                            Console.WriteLine("DNI de referencia no encontrado.");
                        }
                        break;

                    case 'e': // Agregar antes
                        if (cantidad >= MAX)
                        {
                            Console.WriteLine("Lista llena.");
                            break;
                        }

                        Console.Write("Ingrese DNI de referencia: ");
                        string dniRefA = Console.ReadLine();
                        int posRefA = -1;

                        for (int i = 0; i < cantidad; i++)
                        {
                            if (dnis[i] == dniRefA)
                            {
                                posRefA = i;
                                break;
                            }
                        }

                        if (posRefA != -1)
                        {
                            // Mover todo a la derecha desde la posición encontrada
                            for (int i = cantidad; i > posRefA; i--)
                            {
                                dnis[i] = dnis[i - 1];
                                nombres[i] = nombres[i - 1];
                                apellidos[i] = apellidos[i - 1];
                                fechasNac[i] = fechasNac[i - 1];
                                direcciones[i] = direcciones[i - 1];
                                telefonos[i] = telefonos[i - 1];
                            }

                            // Pedir datos del nuevo en la posición liberada
                            Console.Write("DNI: ");
                            dnis[posRefA] = Console.ReadLine();
                            Console.Write("Nombres: ");
                            nombres[posRefA] = Console.ReadLine();
                            Console.Write("Apellidos: ");
                            apellidos[posRefA] = Console.ReadLine();
                            Console.Write("Fecha Nacimiento: ");
                            fechasNac[posRefA] = Console.ReadLine();
                            Console.Write("Direccion: ");
                            direcciones[posRefA] = Console.ReadLine();
                            Console.Write("Telefono: ");
                            telefonos[posRefA] = Console.ReadLine();

                            cantidad++;
                            Console.WriteLine("Alumno insertado antes del seleccionado.");
                        }
                        else
                        {
                            Console.WriteLine("DNI de referencia no encontrado.");
                        }
                        break;

                    case 'f': // Mostrar
                        Console.WriteLine("\n--- LISTA DE ALUMNOS ---");
                        if (cantidad == 0)
                        {
                            Console.WriteLine("No hay alumnos cargados.");
                        }
                        else
                        {
                            for (int i = 0; i < cantidad; i++)
                            {
                                Console.WriteLine((i + 1) + ". DNI: " + dnis[i] + " | " + nombres[i] + " " + apellidos[i] + " | Nac: " + fechasNac[i] + " | Dir: " + direcciones[i] + " | Tel: " + telefonos[i]);
                            }
                        }
                        break;

                    default:
                        Console.WriteLine("Opcin no valida.");
                        break;
                }

                if (opcion != 'g')
                {
                    Console.WriteLine("\nPresione una tecla para continuar...");
                    Console.ReadKey();
                }

            } while (opcion != 'g');
        }
    }
}