﻿using System;
using System.Collections.Generic;

namespace RegistroPacientes
{
   
    public class Paciente
    {
        public string Codigo { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }

        public Paciente(string codigo, string nombres, string apellidos, string direccion, string telefono)
        {
            Codigo = codigo;
            Nombres = nombres;
            Apellidos = apellidos;
            Direccion = direccion;
            Telefono = telefono;
        }

        public override string ToString()
        {
            return $"Código: {Codigo} | Nombre: {Nombres} {Apellidos} | Dirección: {Direccion} | Teléfono: {Telefono}";
        }
    }

    class Program
    {
        static List<Paciente> listaPacientes = new List<Paciente>();

        static void Main(string[] args)
        {
            int opcion;
            do
            {
                Console.Clear();
                Console.WriteLine("SISTEMA DE REGISTRO DE PACIENTES    ");
                Console.WriteLine("a-Registrar un nuevo paciente");
                Console.WriteLine("b-Eliminar paciente");
                Console.WriteLine("c-Actualizar paciente");
                Console.WriteLine("d-Agregar después del seleccionado");
                Console.WriteLine("e-Mostrar listado");
                
                Console.Write("Seleccione una opción: ");

                char input = Console.ReadKey().KeyChar;
                Console.WriteLine();

                switch (char.ToLower(input))
                {
                    case 'a':
                        RegistrarPaciente();
                        break;
                    case 'b':
                        EliminarPaciente();
                        break;
                    case 'c':
                        ActualizarPaciente();
                        break;
                    case 'd':
                        AgregarDespuesDe();
                        break;
                    case 'e':
                        MostrarListado();
                        break;
                    default:
                        Console.WriteLine("\nOpción no válida. Presione cualquier tecla para continuar.");
                        break;
                }
                Console.WriteLine("\nPresione cualquier tecla para volver al menú...");
                Console.ReadKey();
            } while (true);
        }

      
        static void RegistrarPaciente()
        {
            Console.WriteLine("\nREGISTRAR NUEVO PACIENTE");
            Paciente nuevo = PedirDatosPaciente();

            if (listaPacientes.Exists(p => p.Codigo == nuevo.Codigo))
            {
                Console.WriteLine("Error: Ya existe un paciente registrado con ese código.");
                return;
            }

            listaPacientes.Add(nuevo);
            Console.WriteLine("Paciente registrado con éxito.");
        }

      
        static void EliminarPaciente()
        {
            Console.WriteLine("\nELIMINAR PACIENTE");
            if (listaPacientes.Count == 0)
            {
                Console.WriteLine("La lista de pacientes está vacía.");
                return;
            }

            MostrarListado();
            Console.Write("\nIngrese el código del paciente a eliminar: ");
            string codigo = Console.ReadLine();

            Paciente paciente = listaPacientes.Find(p => p.Codigo.Equals(codigo, StringComparison.OrdinalIgnoreCase));

            if (paciente != null)
            {
                listaPacientes.Remove(paciente);
                Console.WriteLine("Paciente eliminado correctamente.");
            }
            else
            {
                Console.WriteLine("No se encontró ningún paciente con ese código.");
            }
        }

       
        static void ActualizarPaciente()
        {
            Console.WriteLine("\nACTUALIZAR PACIENTE");
            if (listaPacientes.Count == 0)
            {
                Console.WriteLine("La lista de pacientes está vacía.");
                return;
            }

            Console.Write("Ingrese el código del paciente a modificar: ");
            string codigo = Console.ReadLine();

            Paciente paciente = listaPacientes.Find(p => p.Codigo.Equals(codigo, StringComparison.OrdinalIgnoreCase));

            if (paciente == null)
            {
                Console.WriteLine("Paciente no encontrado.");
                return;
            }

            Console.WriteLine("\nDejar el campo en blanco para mantener el valor actual:");

            Console.Write($"Nombres [{paciente.Nombres}]: ");
            string nombres = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(nombres)) paciente.Nombres = nombres;

            Console.Write($"Apellidos [{paciente.Apellidos}]: ");
            string apellidos = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(apellidos)) paciente.Apellidos = apellidos;

            Console.Write($"Dirección [{paciente.Direccion}]: ");
            string direccion = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(direccion)) paciente.Direccion = direccion;

            Console.Write($"Teléfono [{paciente.Telefono}]: ");
            string telefono = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(telefono)) paciente.Telefono = telefono;

            Console.WriteLine("Datos del paciente actualizados con éxito.");
        }

     
        static void AgregarDespuesDe()
        {
            Console.WriteLine("\nAGREGAR DESPUÉS DEL SELECCIONADO");
            if (listaPacientes.Count == 0)
            {
                Console.WriteLine("La lista está vacía. Registre primero un paciente.");
                return;
            }

            MostrarListado();
            Console.Write("\nIngrese el código del paciente después del cual desea insertar: ");
            string codigoReferencia = Console.ReadLine();

            int indice = listaPacientes.FindIndex(p => p.Codigo.Equals(codigoReferencia, StringComparison.OrdinalIgnoreCase));

            if (indice == -1)
            {
                Console.WriteLine("No se encontró el paciente seleccionado.");
                return;
            }

            Console.WriteLine("\nIngrese los datos del nuevo paciente:");
            Paciente nuevo = PedirDatosPaciente();

            if (listaPacientes.Exists(p => p.Codigo == nuevo.Codigo))
            {
                Console.WriteLine("Error: El código del nuevo paciente ya existe.");
                return;
            }

           
            listaPacientes.Insert(indice + 1, nuevo);
            Console.WriteLine($"Paciente insertado exitosamente después del código {codigoReferencia}.");
        }

     
        static void MostrarListado()
        {
            Console.WriteLine("\nLISTADO DE PACIENTES");
            if (listaPacientes.Count == 0)
            {
                Console.WriteLine("No hay pacientes registrados.");
                return;
            }

            for (int i = 0; i < listaPacientes.Count; i++)
            {
                Console.WriteLine($"[{i + 1}] {listaPacientes[i]}");
            }
        }

     
        static Paciente PedirDatosPaciente()
        {
            Console.Write("Código: ");
            string codigo = Console.ReadLine();

            Console.Write("Nombre: ");
            string nombres = Console.ReadLine();

            Console.Write("Apellido: ");
            string apellidos = Console.ReadLine();

            Console.Write("Dirección: ");
            string direccion = Console.ReadLine();

            Console.Write("Teléfono: ");
            string telefono = Console.ReadLine();

            return new Paciente(codigo, nombres, apellidos, direccion, telefono);
        }
    }
}