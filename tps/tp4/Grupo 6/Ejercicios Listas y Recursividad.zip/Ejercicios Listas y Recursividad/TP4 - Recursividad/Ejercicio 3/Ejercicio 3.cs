﻿class Program
{
    static void Main(string[] args)
    {
        int[] vector = { 34, 7, 23, 32, 5, 62, 1 };

        Console.WriteLine("Vector desordenado:");
        MostrarVector(vector);

        OrdenarVectorRecursivo(vector, 0, vector.Length - 1);

        Console.WriteLine("\nVector ordenado:");
        MostrarVector(vector);
    }

    static void MostrarVector(int[] arr)
    {
        Console.WriteLine(string.Join(" ", arr));
    }

    static void OrdenarVectorRecursivo(int[] arr, int inicio, int fin)
    {
        if (inicio >= fin)
        {
            return;
        }

        int indice = ObtenerIndice(arr, inicio, fin);

        OrdenarVectorRecursivo(arr, inicio, indice - 1);

        OrdenarVectorRecursivo(arr, indice + 1, fin);
    }

    static int ObtenerIndice(int[] arr, int inicio,int fin)
    {
        int indice = arr[fin];
        int i = inicio - 1;

        for(int j = inicio; j < fin;  j++)
        {
            if (arr[j] < indice)
            {
                i++;

                int auxiliar = arr[i];
                arr[i] = arr[j];
                arr[j] = auxiliar; 
            }
        }

        int auxiliarIndice = arr[i + 1];
        arr[i + 1] = arr[fin];
        arr[fin] = auxiliarIndice;

        return i + 1;
    }
}