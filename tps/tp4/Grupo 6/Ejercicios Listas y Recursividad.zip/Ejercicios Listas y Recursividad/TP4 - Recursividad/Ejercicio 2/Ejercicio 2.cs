﻿class Program
{
    static void Main(string[] args)
    {
        Console.Write("Ingrese un número entero positivo: ");

        string entrada = Console.ReadLine();

        if (int.TryParse(entrada, out int numero) && numero >= 0)
        {
            long resultado = Factorial(numero);

            Console.WriteLine($"El factorial de {numero} es: {resultado}");
        }
        else
        {
            Console.WriteLine("Error: Debe ingresar un número entero mayor o igual a 0.");
        }
    }

        static long Factorial(int n)
    {
        if (n <= 1)
        {
            return 1;
        }

        return n * Factorial(n - 1);
    }
}
