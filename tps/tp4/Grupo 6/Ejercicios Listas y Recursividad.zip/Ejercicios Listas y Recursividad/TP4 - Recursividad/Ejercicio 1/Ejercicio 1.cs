﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Cuenta Regresiva: ");

        ImprimirCuentaRegresiva(10);

        Console.WriteLine();
    }

    static void ImprimirCuentaRegresiva(int n)
    {
        if (n <= 0)
        {
            return;
        }

        Console.Write(n + " ");

        ImprimirCuentaRegresiva(n - 1);
    }
}