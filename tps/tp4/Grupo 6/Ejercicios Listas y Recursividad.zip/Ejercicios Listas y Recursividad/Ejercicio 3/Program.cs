﻿using System;
using System.Collections.Generic;

namespace CineApp
{
    class Persona
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
    }

    class Program
    {
        static List<Persona> personas = new List<Persona>();
        static Random rnd = new Random();

        static void Main(string[] args)
        {
            // Generar lista inicial aleatoria
            int cantidad = rnd.Next(0, 51); // entre 0 y 50
            for (int i = 0; i < cantidad; i++)
            {
                int edad = rnd.Next(5, 61); // entre 5 y 60
                personas.Add(new Persona { Nombre = "Persona" + i, Edad = edad });
            }

            int opcion;
            do
            {
                Console.WriteLine("\n--- MENU CINE ---");
                Console.WriteLine("1. Mostrar listado");
                Console.WriteLine("2. Agregar persona");
                Console.WriteLine("3. Eliminar persona");
                Console.WriteLine("4. Actualizar persona");
                Console.WriteLine("5. Insertar después de alguien");
                Console.WriteLine("6. Calcular recaudación total");
                Console.WriteLine("0. Salir");
                Console.Write("Opción: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1: MostrarListado(); break;
                    case 2: AgregarPersona(); break;
                    case 3: EliminarPersona(); break;
                    case 4: ActualizarPersona(); break;
                    case 5: InsertarDespues(); break;
                    case 6: CalcularRecaudacion(); break;
                }

            } while (opcion != 0);
        }

        static void MostrarListado()
        {
            Console.WriteLine("\n--- LISTADO ---");
            for (int i = 0; i < personas.Count; i++)
            {
                Console.WriteLine($"{i}. {personas[i].Nombre} - Edad: {personas[i].Edad}");
            }
        }

        static void AgregarPersona()
        {
            Console.Write("Nombre: ");
            string nombre = Console.ReadLine();
            Console.Write("Edad: ");
            int edad = int.Parse(Console.ReadLine());
            personas.Add(new Persona { Nombre = nombre, Edad = edad });
        }

        static void EliminarPersona()
        {
            MostrarListado();
            Console.Write("Ingrese posición a eliminar: ");
            int pos = int.Parse(Console.ReadLine());
            if (pos >= 0 && pos < personas.Count)
                personas.RemoveAt(pos);
        }

        static void ActualizarPersona()
        {
            MostrarListado();
            Console.Write("Ingrese posición a actualizar: ");
            int pos = int.Parse(Console.ReadLine());
            if (pos >= 0 && pos < personas.Count)
            {
                Console.Write("Nuevo nombre: ");
                personas[pos].Nombre = Console.ReadLine();
                Console.Write("Nueva edad: ");
                personas[pos].Edad = int.Parse(Console.ReadLine());
            }
        }

        static void InsertarDespues()
        {
            MostrarListado();
            Console.Write("Ingrese posición después de la cual insertar: ");
            int pos = int.Parse(Console.ReadLine());
            if (pos >= 0 && pos < personas.Count)
            {
                Console.Write("Nombre: ");
                string nombre = Console.ReadLine();
                Console.Write("Edad: ");
                int edad = int.Parse(Console.ReadLine());
                personas.Insert(pos + 1, new Persona { Nombre = nombre, Edad = edad });
            }
        }

        static int CalcularPrecio(int edad)
        {
            if (edad < 12) return 500;
            else if (edad < 18) return 800;
            else return 1200;
        }

        static void CalcularRecaudacion()
        {
            int total = 0;
            foreach (var p in personas)
            {
                total += CalcularPrecio(p.Edad);
            }
            Console.WriteLine("Total recaudado: $" + total);
        }
    }
}
