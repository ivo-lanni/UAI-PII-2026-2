﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_6
{
    internal class ListaPersonas
    {
        private Nodo cabeza;
        private Nodo cola;
        private Random rnd = new Random();

        public void GenerarListaAleatoria()
        {
            int cantidad = rnd.Next(0, 51);
            for (int i = 1; i <= cantidad; i++)
            {
                int edad = rnd.Next(5, 61);
                Agregar(new Persona
                {
                    Id = i,
                    Edad = edad,
                    PrecioEntrada = CalcularPrecio(edad)
                });
            }
        }

        private decimal CalcularPrecio(int edad)
        {
            if (edad < 12) return 500;
            if (edad < 18) return 800;
            if (edad < 60) return 1200;
            return 700;
        }

        public void Agregar(Persona p)
        {
            Nodo nuevo = new Nodo(p);
            if (cabeza == null)
            {
                cabeza = cola = nuevo;
            }
            else
            {
                cola.Siguiente = nuevo;
                nuevo.Anterior = cola;
                cola = nuevo;
            }
        }

        public bool Eliminar(int id)
        {
            Nodo actual = cabeza;
            while (actual != null)
            {
                if (actual.Datos.Id == id)
                {
                    if (actual.Anterior != null)
                        actual.Anterior.Siguiente = actual.Siguiente;
                    else
                        cabeza = actual.Siguiente;

                    if (actual.Siguiente != null)
                        actual.Siguiente.Anterior = actual.Anterior;
                    else
                        cola = actual.Anterior;

                    return true;
                }
                actual = actual.Siguiente;
            }
            return false;
        }

        public bool Actualizar(Persona p)
        {
            Nodo actual = cabeza;
            while (actual != null)
            {
                if (actual.Datos.Id == p.Id)
                {
                    actual.Datos.Edad = p.Edad;
                    actual.Datos.PrecioEntrada = CalcularPrecio(p.Edad);
                    return true;
                }
                actual = actual.Siguiente;
            }
            return false;
        }

        public List<Persona> Listar()
        {
            List<Persona> lista = new List<Persona>();
            Nodo actual = cabeza;
            while (actual != null)
            {
                lista.Add(actual.Datos);
                actual = actual.Siguiente;
            }
            return lista;
        }

        public decimal TotalRecaudado()
        {
            decimal total = 0;
            Nodo actual = cabeza;
            while (actual != null)
            {
                total += actual.Datos.PrecioEntrada;
                actual = actual.Siguiente;
            }
            return total;
        }
    }
}
