﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_6
{
    internal class Persona
    {
        public int Id { get; set; }
        public int Edad { get; set; }
        public decimal PrecioEntrada { get; set; }

        public override string ToString()
        {
            return $"{Id} - Edad: {Edad} - Entrada: ${PrecioEntrada}";
        }
    }
}
