﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio_6
{
    public partial class Form1 : Form
    {
        private ListaPersonas lista = new ListaPersonas();

        public Form1()
        {
            InitializeComponent();
            lista.GenerarListaAleatoria();
            MostrarListado();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtId.Text);
            int edad = int.Parse(txtEdad.Text);
            var p = new Persona { Id = id, Edad = edad };
            lista.Agregar(p);
            MostrarListado();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtId.Text);
            if (lista.Eliminar(id))
                MessageBox.Show("Persona eliminada.");
            else
                MessageBox.Show("Persona no encontrada.");
            MostrarListado();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtId.Text);
            int edad = int.Parse(txtEdad.Text);
            var p = new Persona { Id = id, Edad = edad };
            if (lista.Actualizar(p))
                MessageBox.Show("Persona actualizada.");
            else
                MessageBox.Show("Persona no encontrada.");
            MostrarListado();
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            MostrarListado();
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Total recaudado: $" + lista.TotalRecaudado());
        }

        private void MostrarListado()
        {
            dgvPersonas.DataSource = null;
            dgvPersonas.DataSource = lista.Listar();
        }
    }
}