﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio_5
{
    public partial class Form1 : Form
    {
        private ListaPaciente lista = new ListaPaciente();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            var p = new Paciente
            {
                Codigo = int.Parse(txtCodigo.Text),
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtTelefono.Text
            };
            lista.Agregar(p);
            MessageBox.Show("Paciente registrado.");
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int codigo = int.Parse(txtCodigo.Text);
            if (lista.Eliminar(codigo))
                MessageBox.Show("Paciente eliminado.");
            else
                MessageBox.Show("Paciente no encontrado.");
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            var p = new Paciente
            {
                Codigo = int.Parse(txtCodigo.Text),
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtTelefono.Text
            };
            if (lista.Actualizar(p))
                MessageBox.Show("Paciente actualizado.");
            else
                MessageBox.Show("Paciente no encontrado.");
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            dgvPacientes.DataSource = null;
            dgvPacientes.DataSource = lista.Listar();
        }
    }
}