﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_5
{
    public class ListaPaciente
    {
        private Nodo cabeza;
        private Nodo cola;

        public void Agregar(Paciente p)
        {
            Nodo nuevo = new Nodo(p);
            if (cabeza == null)
            {
                cabeza = cola = nuevo;
            }
            else
            {
                cola.Siguiente = nuevo;
                nuevo.Anterior = cola;
                cola = nuevo;
            }
        }

        public bool Eliminar(int codigo)
        {
            Nodo actual = cabeza;
            while (actual != null)
            {
                if (actual.Datos.Codigo == codigo)
                {
                    if (actual.Anterior != null)
                        actual.Anterior.Siguiente = actual.Siguiente;
                    else
                        cabeza = actual.Siguiente;

                    if (actual.Siguiente != null)
                        actual.Siguiente.Anterior = actual.Anterior;
                    else
                        cola = actual.Anterior;

                    return true;
                }
                actual = actual.Siguiente;
            }
            return false;
        }

        public bool Actualizar(Paciente p)
        {
            Nodo actual = cabeza;
            while (actual != null)
            {
                if (actual.Datos.Codigo == p.Codigo)
                {
                    actual.Datos.Nombre = p.Nombre;
                    actual.Datos.Apellido = p.Apellido;
                    actual.Datos.Direccion = p.Direccion;
                    actual.Datos.Telefono = p.Telefono;
                    return true;
                }
                actual = actual.Siguiente;
            }
            return false;
        }

        public List<Paciente> Listar()
        {
            List<Paciente> lista = new List<Paciente>();
            Nodo actual = cabeza;
            while (actual != null)
            {
                lista.Add(actual.Datos);
                actual = actual.Siguiente;
            }
            return lista;
        }
    }
}
